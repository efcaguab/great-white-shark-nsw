drake::clean(destroy = TRUE)
unlink(c("report.html", "figure", "*.pdf"), recursive = TRUE)
